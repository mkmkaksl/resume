$(document).ready(function() {
  alert("Welcome to My Resume")
})